
import java.util.ArrayList;

import sas.Picture;
import sas.Shapes;

public class SpaceObject {
	
	private Picture picture;
	private Picture explosion;
	
	private double x, y;
	
	private double speedY;
	private double speedX;
	
	private double moveVectorX, moveVectorY;
	
	private boolean isAlive;
	
	private String pictureName;
	
	public int explosionDeley;
	public int shootingDeley;
	
	private ArrayList<SpaceObject[]> projectiles;
	
	public SpaceObject(double x, double y, double width, double height, String pictureName) {
		this.pictureName = pictureName;
		this.x = x;
		this.y = y;
		
		isAlive = true;
		
		projectiles = new ArrayList<SpaceObject[]>();
		
		picture = new Picture(x - (width / 2), y, width , height, "assets//" + pictureName + ".png");
		
		explosion = new Picture(x - 50, y, 100, 70, "assets//explosion0.png");
		explosion.setHidden(true);
		
		shootingDeley = 0;
	}
	
	public boolean isAlive() {
		return isAlive;
	}
	
	public void setAlive() {
		isAlive = true;
	}
	
	public void revive() {
		isAlive = true;
		explosion.setHidden(true);
		picture.setHidden(false);
		picture.reset();
	}
	
	public String getPictureName() {
		return pictureName;
	}
	
	public double getHeight() {
		return picture.getShapeHeight();
	}
	
	public double getWidth() {
		return picture.getShapeWidth();
	}
	
	public void setSpeed(double speedX, double speedY) {
		this.speedX = speedX;
		this.speedY = speedY;
	}
	
	public double getSpeedY() {
		return speedY;
	}
	
	public double getX() {
		return x;
	}
	
	public double getY() {
		return y;
	}
	
	public void setMoveVector(double x, double y) {
		this.moveVectorX = x;
		this.moveVectorY = y;
	}
	
	public void move() {
		move(this.moveVectorX, this.moveVectorY);	//!!!!
	}
	
	public void addPojectileType(SpaceObject projectile, int ammunitionCount) {
		SpaceObject[] projectileType = new SpaceObject[ammunitionCount];
		
		for(int i = 0; i < projectileType.length; i++ ) {
			projectileType[i] = new SpaceObject(projectile.getX(), projectile.getY(), projectile.getWidth(), projectile.getHeight(), projectile.getPictureName());
			projectileType[i].setMoveVector(projectile.moveVectorX, projectile.moveVectorY);
			projectileType[i].setHidden(true);
		}
		
		projectiles.add(projectileType);
	}
	/*
	public void moveProjectiles() {
		for(int i = 0; i < projectiles.size(); i++) {
			for(int o = 0; o < projectiles.get(i).length; o++) {
				projectiles.get(i)[o].move();
				if(projectiles.get(i)[o].getProjectiles().size() != 0) { //if the projectile has projectiles, these move
					projectiles.get(i)[o].moveProjectiles();
				}
			}
		}
	}*/
	
	public void move(double x, double y) {
		picture.move(x, y);
		this.x = this.x + x;
		this.y= this.y + y;
	}
	
	public void moveTo(double x, double y) {
		picture.moveTo(x, y);
		this.x = x; 
		this.y = y;
	}
	
	public Shapes getPicture() {
		return picture;
	}
	
	public void explode() {
		picture.setHidden(true);
		explosion = new Picture(x - 50, y, 100, 70, "assets//explosion0.png");
		picture.setHidden(true) ;
		
		isAlive = false;
		
	}
	
	public ArrayList<SpaceObject[]> getProjectiles() {
		return projectiles;
	}
	
	
	public void setHidden(boolean hidden) {
		picture.setHidden(hidden);
		explosion.setHidden(hidden);
	}
	
	public void appear() {
		picture.setHidden(false);
	}
	
	
	public boolean isHidden() {
		if(picture.getHidden() && explosion.getHidden()) return true;
		else return false;
	}
	
}
