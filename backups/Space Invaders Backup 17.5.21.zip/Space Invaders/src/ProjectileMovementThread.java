
public class ProjectileMovementThread extends Thread {
	
	SpaceObject[] projectiles0;
	public static int EXPLOSION_TIME;
	
	public ProjectileMovementThread(SpaceObject[] projectiles0, int EXPLOSION_TIME) {
		this.projectiles0 = projectiles0;
		ProjectileMovementThread.EXPLOSION_TIME = EXPLOSION_TIME;
	}
	
	public void run() {
		for(int i = 0; i < projectiles0.length; i++) {
			if(!projectiles0[i].isHidden()) {
				if(projectiles0[i].isAlive()) {
					projectiles0[i].move();
				} else {
					if(projectiles0[i].explosionDeley == EXPLOSION_TIME) {
						projectiles0[i].setHidden(true);
						projectiles0[i].setAlive();
						projectiles0[i].explosionDeley = 0;
					} else {
						projectiles0[i].explosionDeley++;
					}
				}
			}
		}
	}
	
}
