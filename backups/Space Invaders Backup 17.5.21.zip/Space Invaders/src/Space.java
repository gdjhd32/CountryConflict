import java.awt.Color;
import java.util.ArrayList;

import sas.Picture;
import sas.View;
import sas.Text;

public class Space {
	
	public static final int EXPLOSION_TIME = 200;
	public static final int PROJECTILE_TYPE0_FIRE_DELEY = 75; 
	
	public static final boolean TWODIMENSIONAL_FLIGHT = true;
	
	public static void main(String[] args) {
		new Space();	
	}
	
	View fenster;
	
	SpaceObject[] asteroids;
	SpaceObject ufo;
	
	boolean end;
	
	int points;
	Text pointsText, munition0Text;	
	
	public Space() {
		start();
		
		execute();
	}
	
	private void start() {
		points = 0;
		end = false;
		
		fenster = new View(500, 500);
		
		@SuppressWarnings("unused")
		Picture background = new Picture(0, 0, "assets//background0.jpg");
		
		pointsText = new Text(0, 50, "Points: " + points);
		pointsText.setFontColor(Color.WHITE);
		
		munition0Text = new Text(0, 15, "Munition Type0 left: ");
		munition0Text.setFontColor(Color.WHITE);
		
		
		ufo = new SpaceObject(fenster.getWidth() / 2, fenster.getHeight() - (2 * 50), 50, 100, "rocket2");
		SpaceObject projectileType0 = new SpaceObject(-50, -50, 15, 20, "rocket1"); 
		projectileType0.setMoveVector(0, -1);
		projectileType0.setHidden(true);
		ufo.addPojectileType(projectileType0, 3); 
		
		
		asteroids = new SpaceObject[5];
		for(int i = 0; i < asteroids.length; i++) {
			asteroids[i] = new SpaceObject((int) (Math.random() * 450 + 1), 0, 50, 50, "planet" + i);
			asteroids[i].setSpeed(0, Math.random());
		}
		
	}
	
	@SuppressWarnings("null")
	private void execute() {
		
		while(!fenster.keyEnterPressed() && !end) {
			
			SpaceObject[] projectiles0 = ufo.getProjectiles().get(0);

			for(int i = 0; i < asteroids.length; i++) {
				if(asteroids[i].isAlive()) {
					  
					//asteroids collision
					if(asteroids[i].getPicture().intersects(ufo.getPicture())) {	//ufo with asteroids
						asteroids[i].explode();
						ufo.explode();
						end = true;
					}
					
					//for each projectile type one for loop
					for(int o = 0; o < projectiles0.length; o++) {
						if(asteroids[i].getPicture().intersects(projectiles0[o].getPicture())) { //ufo projectiles with asteroids
							asteroids[i].explode();
							projectiles0[o].explode();
						}
					}
					
					//asteroids movement
					if(asteroids[i].getY() < fenster.getHeight()) {
						asteroids[i].move(0, 1 + asteroids[i].getSpeedY());
					} else {
						asteroids[i].moveTo((int) (Math.random() * 450 + 1), 50 - 50);
						asteroids[i].setSpeed(0, Math.random());
						points++;
						pointsText.setText("Points: " + points);
					}
				} else {
					if(asteroids[i].explosionDeley == EXPLOSION_TIME) {
						asteroids[i].revive();
						asteroids[i].moveTo((int) (Math.random() * 450 + 1), 0);
						asteroids[i].setSpeed(0, Math.random());
						asteroids[i].explosionDeley = 0;
					} else {
						asteroids[i].explosionDeley++;
					}
				}
				
			}
			
			//ufo projectile stuff
			
			//shooting
			if(fenster.keyPressed(' ')) {
				
				for(int i = 0; i < projectiles0.length; i++) {
					if(projectiles0[i].isHidden() && projectiles0[i].isAlive() && ufo.shootingDeley >= PROJECTILE_TYPE0_FIRE_DELEY) {
						projectiles0[i].moveTo(ufo.getX(), ufo.getY());
						projectiles0[i].appear();
						ufo.shootingDeley = 0;
					}
				}
			}
			
			if(ufo.shootingDeley < PROJECTILE_TYPE0_FIRE_DELEY) {
				ufo.shootingDeley++;
			}
			
			//projectile movement
			int munition0Count = 0;
			
			for(int i = 0; i < projectiles0.length; i++) {
				if(!projectiles0[i].isHidden()) {
					if(projectiles0[i].isAlive()) {
						projectiles0[i].move();
					} else {
						if(projectiles0[i].explosionDeley == EXPLOSION_TIME) {
							projectiles0[i].setHidden(true);
							projectiles0[i].setAlive();
							projectiles0[i].explosionDeley = 0;
						} else {
							projectiles0[i].explosionDeley++;
						}
					}
				} else {
					munition0Count++;
				}
			}
			munition0Text.setText("Munition Type0 left: " + munition0Count);
			
			//projectile out of bounds
			for(int i = 0; i < projectiles0.length; i++) {
				if(projectiles0[i].getY() < 0) {
					projectiles0[i].setHidden(true);
				}
			}
			
			
			//player movement
			if(fenster.keyLeftPressed() && ufo.getX() > 0) {
				ufo.move(-1, 0);
			}
			if(fenster.keyRightPressed() && ufo.getX() < 500) {
				ufo.move(1, 0);
			}
			if(TWODIMENSIONAL_FLIGHT) {
				if(fenster.keyDownPressed() && ufo.getY() < 500) {
					ufo.move(0, 1);
				}
				if(fenster.keyUpPressed() && ufo.getY() > 0) {
					ufo.move(0, -1);
				}
			}
			
			
			//fenster.wait(5);
			fenster.wait((int) (5 - (0.1 * (points / 4))));
		
		}
	}
	
}
