
public class DatabaseControllerStarter {

	public static void main(String[] args) {
		new DatabaseController("C:\\Users\\wilga\\eclipse-workspace\\own database controller\\src");
	}

}
