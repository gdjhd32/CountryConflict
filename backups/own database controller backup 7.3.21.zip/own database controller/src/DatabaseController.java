import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class DatabaseController {

	String pathToDatabase;
	File data, dataConnecters, categories; // main folder

	public DatabaseController(String pathToDatabase) {
		this.pathToDatabase = pathToDatabase;

		start();
		/*
		 * for (int i = 0; i < getAllDataFromCategory("Schwein").length; i++) {
		 * System.out.println(getAllDataFromCategory("Schwein")[i]); }
		 * 
		 * for (int i = 0; i < getAllCategoriesFromData("S Schweineschnitzel").length;
		 * i++) {
		 * System.out.println(getAllCategoriesFromData("S Schweineschnitzel")[i]); }
		 * 
		 * File temp1 = new File(pathToDatabase + "\\categories\\Braten.txt");
		 * temp1.delete(); try { Thread.sleep(1000); } catch (InterruptedException e) {
		 * e.printStackTrace(); } String[] temp2 = { "S Schweinebraten",
		 * "W Schweinebraten" }; System.out.println(addCategory("Braten", temp2));
		 * 
		 * 
		 * File temp5 = new File(pathToDatabase + "\\data\\" + "W
		 * Schweinebraten" + ".txt"); temp5.delete();
		 */
		
		System.out.println("Was able to remove data from category: " + removeDataFormCategory("Schwein", "W Schweinebraten"));
		
		System.out.println("Was able to add data to category: " + addDataToCategory("W Schweinebraten", "Schwein"));
		

		/*
		 * try { Thread.sleep(1000); } catch (InterruptedException e) { // TODO
		 * Auto-generated catch block e.printStackTrace(); }
		 * 
		 * String[] temp3 = { "Man braucht einen Braten." }; 
		 * String[] temp4 = {
		 * "Schwein", "Braten" }; System.out.println(addData("W Schweinebraten", temp3,
		 * temp4));
		 */
	}

	public boolean removeDataFormCategory(String nameCategory, String nameData) {
		// delete from category file
		if (!removeContentFromTxt("categories", nameCategory, nameData))
			return false;

		// delete from connector
		if (!removeContentFromTxt("data connectors", nameData + " Connector", nameCategory))
			return false;

		return true;
	}

	private boolean removeContentFromTxt(String nameFolder, String nameTxt, String nameContent) {
		File txt = new File(pathToDatabase + "\\" + nameFolder + "\\" + nameTxt + ".txt");
		
		ArrayList<String> categoryFileContent = new ArrayList<String>();
		String[] allDataFromCategory = getAllDataFromTxt(nameFolder, nameTxt);
		for (int i = 0; i < allDataFromCategory.length; i++) {
			if (!allDataFromCategory[i].equals(nameContent)) {
				categoryFileContent.add(allDataFromCategory[i]);
			}
		}

		try {
			FileWriter removeDataFormCategoryFileWriter = new FileWriter(txt);
			for (int i = 0; i < categoryFileContent.size(); i++) {
				removeDataFormCategoryFileWriter.write(categoryFileContent.get(i));
				removeDataFormCategoryFileWriter.write(System.getProperty("line.separator"));
				removeDataFormCategoryFileWriter.flush();
			}
			removeDataFormCategoryFileWriter.close();
		} catch (IOException e) {
			System.out.println(
					"An error occured while creating new FileWriter in removeDataFormCategory() in DatabaseController");
			e.printStackTrace();
			return false;
		}

		return true;
	}

	public boolean addDataToCategory(String nameData, String nameCategory) {
		//remove from category
		if(!addContentToTxt("categories", nameCategory, nameData)) return false;
		
		//remove from connector
		if(!addContentToTxt("data connectors", nameData + " Connector", nameCategory)) return false;
		
		return true;
	}
	
	private boolean addContentToTxt(String nameFolder, String nameTxt, String nameContent) {
		
		File categoryFile = new File(pathToDatabase + "\\" + nameFolder + "\\" + nameTxt + ".txt");
		if (categoryFile.exists()) {
			try {
				FileWriter addDataToCategoryFileWriter = new FileWriter(categoryFile, false);
				addDataToCategoryFileWriter.write(nameContent);
				addDataToCategoryFileWriter.write(System.getProperty("line.separator"));
				addDataToCategoryFileWriter.flush();
				addDataToCategoryFileWriter.close();
			} catch (IOException e) {
				System.out.println(
						"An error occured while creating new FileWriter in addDataToCategory() in DatabaseController");
				e.printStackTrace();
				return false;
			}
			return true;
		} else {
			return false;
		}
	}

	public boolean addData(String nameNewData, String[] contentInData, String[] namesCategories) {
		// nameNewData --> creates the new file in the data folder
		File newData = new File(pathToDatabase + "\\data\\" + nameNewData + ".txt");
		if (newData.exists()) {
			return false;
		}

		try {
			newData.createNewFile();
		} catch (IOException e) {
			System.out.println("An error occured while creating new File in addData() in DatabaseController");
			e.printStackTrace();
		}

		// contentInData --> puts the content in the new file in the data folder
		if (contentInData != null) {
			try {
				FileWriter addDataContentFileWriter = new FileWriter(newData, false);
				for (int i = 0; i < contentInData.length; i++) {
					addDataContentFileWriter.write(contentInData[i]);
					addDataContentFileWriter.write(System.getProperty("line.separator"));
					addDataContentFileWriter.flush();
				}
				addDataContentFileWriter.close();
			} catch (IOException e) {
				System.out.println(
						"An error occured while creating new FileWriter addDataContentFileWriter in addCategory() in Databasecontroller");
				e.printStackTrace();
				return false;
			}
		}

		// dataConnecter --> adds the names of the categories in the connector file
		File newDataConnector = new File(pathToDatabase + "\\data connectors\\" + nameNewData + " Connector" + ".txt");
		if (!newDataConnector.exists()) {
			try {
				newDataConnector.createNewFile();
			} catch (IOException e) {
				System.out.println(
						"An error occured while creating new file data connecter in addCategory() in Databasecontroller");
				e.printStackTrace();
				return false;
			}
		}

		if (namesCategories != null) {
			try {
				FileWriter addDataConnectorFileWriter = new FileWriter(newDataConnector, false);
				for (int i = 0; i < namesCategories.length; i++) {
					addDataConnectorFileWriter.write(namesCategories[i]);
					addDataConnectorFileWriter.write(System.getProperty("line.separator"));
					addDataConnectorFileWriter.flush();
				}
				addDataConnectorFileWriter.close();
			} catch (IOException e) {
				System.out.println(
						"An error occured while creating new FileWriter addDataConnectorFileWriter in addCategory() in Databasecontroller");
				e.printStackTrace();
				return false;
			}

			// categories --> adds the name of the new file to the categories
			File[] categories = new File[namesCategories.length];

			for (int i = 0; i < categories.length; i++) {
				categories[i] = new File(pathToDatabase + "\\categories\\" + namesCategories[i] + ".txt");
				if (!categories[i].exists()) {
					return false;
				}
				try {
					FileWriter addDataCategoriesFileWriter = new FileWriter(categories[i], false);
					addDataCategoriesFileWriter.write(nameNewData);
					addDataCategoriesFileWriter.write(System.getProperty("line.separator"));
					addDataCategoriesFileWriter.close();
				} catch (IOException e) {
					System.out.println(
							"An error occured while creating new FileWriter addDataCategoriesFileWriter in addCategory() in Databasecontroller");
					e.printStackTrace();
					return false;
				}
			}

		}

		return true;
	}

	public boolean addCategory(String nameNewCategory, String[] nameDataInNewCategory) {
		File newCategory = new File(pathToDatabase + "\\categories\\" + nameNewCategory + ".txt");
		if (newCategory.exists()) {
			return false;
		} else {
			try {
				newCategory.createNewFile();
			} catch (IOException e) {
				System.out.println("An error occured while creating new File in addCategory() in DatabaseController");
				e.printStackTrace();
				return false;
			}

			if (nameDataInNewCategory != null) {
				try {
					FileWriter addCategoryFileWriter = new FileWriter(newCategory, false);
					for (int i = 0; i < nameDataInNewCategory.length; i++) {
						addCategoryFileWriter.write(nameDataInNewCategory[i]);
						addCategoryFileWriter.write(System.getProperty("line.separator"));
						addCategoryFileWriter.flush();
					}
					addCategoryFileWriter.close();
				} catch (IOException e) {
					System.out.println(
							"An error occured while creating new FileWriter in addCategory() in Databasecontroller");
					e.printStackTrace();
					return false;
				}
			}

			return true;
		}
	}

	public String[] getAllCategoriesFromData(String nameData) {
		File dataConnector = new File(pathToDatabase + "\\data connectors\\" + nameData + " Connecter.txt");

		if (!dataConnector.exists())
			return null;

		ArrayList<String> getAllCategoriesFromData = new ArrayList<String>();

		try {
			Scanner categoryScanner = new Scanner(dataConnector);
			while (categoryScanner.hasNextLine()) {
				getAllCategoriesFromData.add(categoryScanner.nextLine());
			}
			categoryScanner.close();
		} catch (FileNotFoundException e) {
			System.out.println("A file was not found while creating scanner in getAllDataFromCategory");
			e.printStackTrace();
		}

		String[] allCategories = new String[getAllCategoriesFromData.size()];
		for (int i = 0; i < allCategories.length; i++) {
			allCategories[i] = getAllCategoriesFromData.get(i);
		}

		return allCategories;
	}

	public String[] getAllDataFromTxt(String nameFolder, String nameTxt) {
		File txt = new File(pathToDatabase + "\\" + nameFolder + "\\" + nameTxt + ".txt");

		if (!txt.exists()) {
			return null;
		}

		ArrayList<String> allDataFromTxt = new ArrayList<String>();

		try {
			Scanner categoryScanner = new Scanner(txt);
			while (categoryScanner.hasNextLine()) {
				allDataFromTxt.add(categoryScanner.nextLine());
			}
			categoryScanner.close();
		} catch (FileNotFoundException e) {
			System.out.println("A file was not found while creating scanner in getAllDataFromCategory");
			e.printStackTrace();
		}

		String[] allData = new String[allDataFromTxt.size()];
		for (int i = 0; i < allData.length; i++) {
			allData[i] = allDataFromTxt.get(i);
		}

		return allData; // temp
	}

	private void start() {

		// data
		data = new File(pathToDatabase + "\\data");

		if (!data.exists()) {
			data.mkdir();
			System.out.println("New data folder created");
		} else {
			System.out.println("Existing data folder found");
		}

		// sourceConnectowrs

		dataConnecters = new File(pathToDatabase + "\\data connectors");

		if (!dataConnecters.exists()) {
			dataConnecters.mkdir();
			System.out.println("New data connectors folder created");
		} else {
			System.out.println("Existing data connectors folder found");
		}

		// categories

		categories = new File(pathToDatabase + "\\categories");

		if (!categories.exists()) {
			categories.mkdir();
			System.out.println("New categories folder created");
		} else {
			System.out.println("Existing categories folder found");
		}

	}

}
