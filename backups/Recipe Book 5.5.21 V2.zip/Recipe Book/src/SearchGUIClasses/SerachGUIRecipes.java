package SearchGUIClasses;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JTextField;
import OtherGUIElements.ScrollPaneWithButtons;
import RecipeEditingGUI.RecipeEditingGUI;

@SuppressWarnings("serial")
public class SerachGUIRecipes extends JPanel {
	
	SearchGUI window;
	
	ScrollPaneWithButtons recipesSelection; //???????
	
	public SerachGUIRecipes(SearchGUI window) {
		this.window = window;
		
		start();
	}
	
	private void start() {
		this.setBounds(window.getBounds());
		this.setVisible(true);
		this.setLayout(null);
		window.add(this);
		
		JButton recipes = new JButton("recipes");
		recipes.setBackground(Color.GREEN);
		recipes.setBounds(0, 0, this.getWidth() / 3, 50);
		recipes.setFocusable(false);
		this.add(recipes);
		
		JButton categories = new JButton("categories");
		categories.setBounds(this.getWidth() / 3, 0, this.getWidth() / 3, 50);
		categories.setFocusable(false);
		categories.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				setVisible(false);
				window.categories.setVisible(true);
				
			}
		});
		this.add(categories);
		
		JButton ingredients = new JButton("ingredients");
		ingredients.setBounds( 2 * this.getWidth() / 3, 0, this.getWidth() / 3, 50);
		ingredients.setFocusable(false);
		ingredients.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				setVisible(false);
				window.ingredients.setVisible(true);
				
			}
		});
		this.add(ingredients);
		
		String[] repipebooks = {"alle", "Simons Rezeptbuch", "Wilkens Rezeptbuch"};		//need to add the data automatic
		
		JComboBox<String> recipebookSelection = new JComboBox<String>(repipebooks);
		recipebookSelection.setBounds(window.getWidth() / 3, 100, window.getWidth() / 3, 50);
		recipebookSelection.setFont(new Font(getFont().getName(), getFont().getStyle(), 20));
		this.add(recipebookSelection);
		
		
		JTextField searchField = new JTextField("-suchen-");
		searchField.setBounds(100, 200, window.getWidth() - 300, 50);
		searchField.setFont(new Font(getFont().getFontName(), getFont().getStyle(), 20));
		this.add(searchField);
		
		JButton search = new JButton("S");
		search.setBounds(window.getWidth() - 200, 200, 50, 49);
		search.setBackground(Color.WHITE);
		search.setFocusable(false);
		search.addActionListener(new ActionListener() {	
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub		----------------> needs functionality
				
			}
		});
		this.add(search);
		
		
		//automation
		ArrayList<ArrayList<Component>> recipesSelectionContent = new ArrayList<ArrayList<Component>>();	
		for(int i = 0; i < 10; i++) {	//!
			
			JButton buttonOne = new JButton(Integer.toString(i));
			buttonOne.setPreferredSize(new Dimension(645, 60));
			buttonOne.setFocusable(false);
			buttonOne.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent arg0) {
					System.out.println("It worked: One of the left Buttons clicked");
					
				}
			});
			
			
			JButton buttonTwo = new JButton("B");
			buttonTwo.setPreferredSize(new Dimension(85, 60));
			buttonTwo.setFocusable(false);
			buttonTwo.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent arg0) {
					System.out.println("It worked: One of the Right Buttons clicked");
					
				}
			});
			
			ArrayList<Component> listAtI = new ArrayList<>();
			listAtI.add(buttonOne);
			listAtI.add(buttonTwo);
			recipesSelectionContent.add(listAtI);
		}
		
		this.recipesSelection = new ScrollPaneWithButtons(100, 300, window.getWidth() - 250, 300, recipesSelectionContent);
		this.add(recipesSelection);
		
		
		JButton newRecipe = new JButton("neues Rezept");
		newRecipe.setBounds(window.getWidth() / 3, 650, window.getWidth() / 3, 50);
		newRecipe.setFocusable(false);
		newRecipe.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				new RecipeEditingGUI();

			}
		});
		this.add(newRecipe);
		
	}
	
	//private void setRecipeSelection(ArrayList<Object[]>[] buttonList) {
		
	//}
}
