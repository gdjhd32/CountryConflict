package OtherGUIElements;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

@SuppressWarnings("serial")
public class SearchAndSelectField extends JPanel { 
	
	final String[] contentNames;
	
	boolean[] selected;
	boolean[] matchSearchRequest;
	
	
	
	String[] namesSearchContent;
	
	
	ScrollPaneWithButtons searchScrollPane;
	ScrollPaneWithButtons selectedScrollPane;
	
	JPanel highestJPanel;
	
	public SearchAndSelectField(int x, int y, int width, int height, String[] namesSearchContent, JPanel highestJPanel) {
		this.setBounds(x, y, width, height);
		this.namesSearchContent = namesSearchContent; // will be gone and the parameter will be renamed
		this.contentNames = namesSearchContent;
		this.highestJPanel = highestJPanel;

		
		start();
	}
	
	private void start() {
		
		selected = new boolean[contentNames.length];
		matchSearchRequest = new boolean[contentNames.length];
		
		for(int i = 0; i < contentNames.length; i++) {
			selected[i] = false;		//because it should start with nothing selected
			matchSearchRequest[i] = true;		//because it should start with displaying everything
		}
	
		
		//right
		
		JTextField searchTextfield = new JTextField("suchen");
		searchTextfield.setBounds(this.getX() + 560, this.getY() - 50, 340, 50);
		searchTextfield.setFont(new Font(getFont().getFontName(), getFont().getStyle(), 20));
		searchTextfield.addKeyListener(new KeyAdapter() {
			
	         public void keyReleased(KeyEvent ke) {
	        	 
	        	 if (ke.getKeyCode() == 10) {
	        		//search algorithm
	 				
	 				searchFor(searchTextfield.getText());
	 				reload();
	        	 }
	         }
	      });
		highestJPanel.add(searchTextfield);
		
		JButton searchButton = new JButton("S");
		searchButton.setFont(new Font(getFont().getFontName(), getFont().getStyle(), 15));
		searchButton.setBackground(Color.WHITE);
		searchButton.setFocusable(false);
		searchButton.setBounds(this.getX() + 500, this.getY() - 50, 60, 50);
		searchButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				//search algorithm
				
				searchFor(searchTextfield.getText());
				reload();
				
			}
		});
		highestJPanel.add(searchButton);
		
				
		this.searchScrollPane = new ScrollPaneWithButtons(this.getX() + 500, this.getY(), 400, this.getHeight(), getSearchResults());
		highestJPanel.add(searchScrollPane);
			
		
		//left 
		
		selectedScrollPane = new ScrollPaneWithButtons(this.getX(), this.getY() - 50, 400, this.getHeight() + 50, getSelected());
		highestJPanel.add(selectedScrollPane);
		

		
		
	}
		
	private void reload() {
		
		searchScrollPane.setNewContent(getSearchResults());
		
		selectedScrollPane.setNewContent(getSelected());
		
		
	}
	
	
	private void searchFor(String searchRequest) {
		if(searchRequest != null) {
			for(int i = 0; i < contentNames.length; i++) {
				if(contentNames[i].toUpperCase().contains(searchRequest.toUpperCase())) {	//ignores cases
					matchSearchRequest[i] = true;
				} else {
					matchSearchRequest[i] = false;
				}
			}
		}
	}
	
	private ArrayList<ArrayList<Component>> getSearchResults() {
		
		ArrayList<ArrayList<Component>> listWithSearchResults = new ArrayList<ArrayList<Component>>();	//will be the return value
		
		for(int i = 0; i < contentNames.length; i++) {
			
			if(matchSearchRequest[i]) {	//generate a layer for search when it matches the search request
				
				ArrayList<Component> listAtIndex = new ArrayList<>();
				
				JButton buttonOne = new JButton(contentNames[i]); 		
				buttonOne.setPreferredSize(new Dimension(380, 50));
				buttonOne.setName(Integer.toString(i));
				buttonOne.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent arg0) {
						for(int i = 0; i < contentNames.length; i++) {
							if(buttonOne.getText().equalsIgnoreCase(contentNames[i])) {
								selected[i] = true;
								reload();
								break;
							}
						}
					}
				});
				buttonOne.setFocusable(false);	
				
				if(selected[i]) { 	//adds the image if its selected to the search side 
					buttonOne.setPreferredSize(new Dimension(325, 50));
					
					JLabel labelOne = new JLabel();
					labelOne.setBackground(Color.WHITE);
					labelOne.setSize(new Dimension(55, 50));
					
					ImageIcon icon = new ImageIcon("C:\\Users\\wilga\\eclipse-workspace\\Recipe Book\\bin\\visuals\\haken.png");
					Image image = icon.getImage();
					Image imageScaled = image.getScaledInstance(labelOne.getWidth(), labelOne.getHeight(), Image.SCALE_SMOOTH);
					ImageIcon iconScaled = new ImageIcon(imageScaled);
					labelOne.setIcon(iconScaled); 
							
					listAtIndex.add(labelOne); //adds the label at position 0
				}
				
				
				
				listAtIndex.add(buttonOne);	//adds the button at position 0 or 1
				listWithSearchResults.add(listAtIndex);
				
			}
		}
		
		return listWithSearchResults;
		
	}
	
	private ArrayList<ArrayList<Component>> getSelected() {
		
		ArrayList<ArrayList<Component>> listWithSelected = new ArrayList<ArrayList<Component>>();	//will be the return value
		
		
		for(int i = 0; i < contentNames.length; i++) {
			
			
			if(selected[i]) {	//generate a layer for selected when it is selected
												
				JTextField textFieldOne = new JTextField("0");
				textFieldOne.setHorizontalAlignment((int) CENTER_ALIGNMENT);
				textFieldOne.addKeyListener(new KeyAdapter() {
					
			         public void keyReleased(KeyEvent ke) {
			        	 if (ke.getKeyChar() <= '0' || ke.getKeyChar() >= '9') {	//checks if text in textFieldOne is valid, triggers also with comma, because it could be two commas
			        		 textFieldOne.setText(correctNumberfield(textFieldOne.getText().toCharArray())); 	//makes text in textFieldOne valid
			        	 }
			         }
			      });
				textFieldOne.setEditable(true);
				textFieldOne.setPreferredSize(new Dimension(60, 50));
				
				
				JTextField textFieldTwo = new JTextField(contentNames[i]);
				textFieldTwo.setFont(new Font(getFont().getFontName(), getFont().getStyle(), 15));
				textFieldTwo.setPreferredSize(new Dimension(244, 50));
				textFieldTwo.setVisible(true);
				textFieldTwo.setFocusable(false);
				textFieldTwo.setEditable(false);
				
				
				JButton buttonThree = new JButton("Back");
				buttonThree.setPreferredSize(new Dimension(75, 50));
				buttonThree.setFocusable(false);
				buttonThree.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent arg0) {
						
						for(int i = 0; i < contentNames.length; i++) {
							if(textFieldTwo.getText().equalsIgnoreCase(contentNames[i])) {
								selected[i] = false;
								break;
							}
						}
						
						reload();
					}
				});
				
				ArrayList<Component> listAtIndex = new ArrayList<>();
				listAtIndex.add(textFieldOne);
				listAtIndex.add(textFieldTwo);
				listAtIndex.add(buttonThree);
				listWithSelected.add(listAtIndex);
			}
		}
		
		return listWithSelected;
		
	}
	
	
	private String correctNumberfield(char[] carArray) {	//dont need this
		ArrayList<Character> list = new ArrayList<Character>();
		boolean nextCommaValid = true;
    	for(int i = 0; i < carArray.length; i++) {
    		if (carArray[i] >= '0' && carArray[i] <= '9' || carArray[i] == ',' && nextCommaValid) {
    			list.add(carArray[i]);
    			if(carArray[i] == ',') {
    				nextCommaValid = false;
    			}
    		}
    	}
    	String newContent = new String();
    	for(int i = 0; i < list.size(); i++) {
    		newContent = newContent + Character.toString((char) list.toArray()[i]);
    	}
    	return newContent;
	}
}
