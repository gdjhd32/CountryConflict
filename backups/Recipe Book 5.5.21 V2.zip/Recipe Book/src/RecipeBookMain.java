import SearchGUIClasses.SearchGUI;

public class RecipeBookMain {

	public static void main(String[] args) {
		new SearchGUI();

	}

}
