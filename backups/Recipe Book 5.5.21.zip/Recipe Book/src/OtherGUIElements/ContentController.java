package OtherGUIElements;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JTextField;

@SuppressWarnings("unused")
public class ContentController {
	
	String[] contentNames;
	
	boolean[] selected;
	boolean[] matchSearchRequest;
	
	
	public ContentController(String[] contentNames) {
		this.contentNames = contentNames;
		
		start();
	}
	
	private void start() {
		
		selected = new boolean[contentNames.length];
		matchSearchRequest = new boolean[contentNames.length];
		
		for(int i = 0; i < contentNames.length; i++) {
			selected[i] = false;		//because it should start with nothing selected
			matchSearchRequest[i] = true;		//because it should start with displaying everything
		}

	}
	
	public ArrayList<ArrayList<Component>> getSelected() {
		
		ArrayList<ArrayList<Component>> listWithSelected = new ArrayList<ArrayList<Component>>();	//will be the return value
		
		for(int i = 0; i < contentNames.length; i++) {
			
			if(selected[i]) {	//generate a layer for selected when it is selected
				
				
			}
		}
		
		return listWithSelected;
	}
	
	public ArrayList<ArrayList<Component>> getSearchResults() {
		return null;
	}
	
	private String correctNumberfield(char[] carArray) {
		ArrayList<Character> list = new ArrayList<Character>();
		boolean nextCommaValid = true;
    	for(int i = 0; i < carArray.length; i++) {
    		if (carArray[i] >= '0' && carArray[i] <= '9' || carArray[i] == ',' && nextCommaValid) {
    			list.add(carArray[i]);
    			if(carArray[i] == ',') {
    				nextCommaValid = false;
    			}
    		}
    	}
    	String newContent = new String();
    	for(int i = 0; i < list.size(); i++) {
    		newContent = newContent + Character.toString((char) list.toArray()[i]);
    	}
    	return newContent;
	}
}
