package RecipeEditingGUI;

import javax.swing.JPanel;

@SuppressWarnings("serial")
public class RecipeEditingGUIThirdPage extends JPanel {

	RecipeEditingGUI window;
	
	public RecipeEditingGUIThirdPage(RecipeEditingGUI window) {
		this.window = window;
		start();
	}
	
	private void start() {
		
	}

}
