package RecipeEditingGUI;

import javax.swing.JFrame;

import org.json.JSONObject;

@SuppressWarnings("serial")
public class RecipeEditingGUI extends JFrame {
	
	RecipeEditingGUIFirstPage firstPage;
	RecipeEditingGUISecondPage secondPage;
	RecipeEditingGUIThirdPage thirdPage;
	
	public RecipeEditingGUI() { //for new Recipe
		start();
	}
	
	public RecipeEditingGUI(JSONObject content) { //for an edit
		
	}
	
	
	private void start() {
		this.setLayout(null);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setSize(1000, 800);
		this.setResizable(false);
		this.setVisible(true);
		
		
		
		@SuppressWarnings("unused")
		JSONObject contentFirstPage = new JSONObject();
		//contentFirstPage.put("name", value)
		
		firstPage = new RecipeEditingGUIFirstPage(this, null);
		this.add(firstPage);
		secondPage = new RecipeEditingGUISecondPage(this);
		this.add(secondPage);
		thirdPage = new RecipeEditingGUIThirdPage(this);
		this.add(thirdPage);
		
	}
}
