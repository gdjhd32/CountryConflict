package SearchGUIClasses;
import javax.swing.JFrame;

@SuppressWarnings("serial")
public class SearchGUI extends JFrame {
	
	SerachGUIRecipes recipes;
	SerachGUICategories categories;
	SerachGUIIngredients ingredients;
	
	public SearchGUI() {
		start();
	}
	
	private void start() {
		this.setLayout(null);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setSize(1000, 800);
		this.setResizable(false);
		this.setVisible(true);
		
		recipes = new SerachGUIRecipes(this);
		categories = new SerachGUICategories(this);
		ingredients = new SerachGUIIngredients(this);
		
		//decide who is first
		ingredients.setVisible(false);
		categories.setVisible(false);
	}
}
