package RecipeEditingGUI;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class RecipeEditingGUISecondPage extends JPanel {

	RecipeEditingGUI window;
	
	public RecipeEditingGUISecondPage(RecipeEditingGUI window) {
		this.window = window;
		
		start();
	}
	
	private void start() {
		this.setBounds(window.getBounds());
		this.setLayout(null);
		this.setVisible(false);
		
		JButton back = new JButton("Back");
		back.setBounds(100, 700, 300, 50);
		back.setFocusable(false);
		back.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				setVisible(false);
				window.firstPage.setVisible(true);
				
			}
		});
		this.add(back);
		
		
		JButton nextPage = new JButton("N�chste Seite");
		nextPage.setBounds(600, 700, 300, 50);
		nextPage.setFocusable(false);
		nextPage.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				setVisible(false);
				window.thirdPage.setVisible(true);
				
			}
		});
		this.add(nextPage);
	}

}
