package RecipeEditingGUI;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.json.JSONArray;
import org.json.JSONObject;

import OtherGUIElements.SearchAndSelectField;

@SuppressWarnings("serial")
public class RecipeEditingGUIFirstPage extends JPanel {
	
	RecipeEditingGUI window;
	JSONObject content;
	

	public RecipeEditingGUIFirstPage(RecipeEditingGUI window, JSONObject content) {
		this.window = window;
		this.content = content;
		
		if(content != null) {
			start(content);
		} else {
			content = new JSONObject();
			
			content.put("Name", "Namen eintragen");
			
			String[] repipebooks = {"nichts", "Simons Rezeptbuch", "Wilkens Rezeptbuch", "Fynns Rezeptbuch"};	//needs to get these automatically, so this will be removed soon
			JSONArray recipeBooksJsonArray = new JSONArray(repipebooks);
			content.put("Kochb�cher", recipeBooksJsonArray);
			
			content.put("Kochbuch", "Fynns Rezeptbuch");
			
			String[] ingredients = {"Hackfleisch", "Tomaten", "Mais", "Nudeln", "Mehl", "Milch", "Eier", "Zucker"};	//needs to get these automatically, so this will be removed soon
			content.put("Zutaten", ingredients);
			
			String[] categories = {"Braten", "Vegetarisch", "Vegan", "Sauce", "Fleisch", "Backofen", "Pfanne", "Fastfood", "Mikrowelle"};	//needs to get these automatically, so this will be removed soon
			content.put("Kategorien", categories);

			start(content);
		}
	}
	
	
	private void start(JSONObject content) {
		
		this.setBounds(window.getBounds());
		this.setLayout(null);
		
		//Name
		JTextField nameTextfield = new JTextField(content.getString("Name"));
		nameTextfield.setBounds((int) (window.getWidth() * 0.04), 25, (int) (window.getWidth() * 0.4), 50);		
		nameTextfield.setFont(new Font(getFont().getFontName(), getFont().getStyle(), 20));
		this.add(nameTextfield);
		
		//recipe book selection
		Object[] repipebooks = content.getJSONArray("Kochb�cher").toList().toArray();	//needs to be automatic, so this will change soon to automatic here
		JComboBox<Object> recipebookSelection = new JComboBox<Object>(repipebooks);
		recipebookSelection.setBounds((int) (window.getWidth() * 0.54), 25, (int) (window.getWidth() * 0.4), 50);
		recipebookSelection.setFont(new Font(getFont().getName(), getFont().getStyle(), 20));
		for(int i = 0; i < recipebookSelection.getItemCount(); i++) {
			if(recipebookSelection.getItemAt(i).toString().equalsIgnoreCase(content.getString("Kochbuch"))) {
				recipebookSelection.insertItemAt(recipebookSelection.getItemAt(i), 1);
				recipebookSelection.removeItemAt(i + 1);
				break;
			}
		}
		recipebookSelection.setSelectedIndex(1);
		this.add(recipebookSelection);
		
		//top
		JButton ingredientsSearchSearchButton = new JButton("S");
		ingredientsSearchSearchButton.setFont(new Font(getFont().getFontName(), getFont().getStyle(), 15));
		ingredientsSearchSearchButton.setBackground(Color.WHITE);
		ingredientsSearchSearchButton.setFocusable(false);
		ingredientsSearchSearchButton.setBounds((int) ( window.getWidth() * 0.54), 125, 60, 50);
		ingredientsSearchSearchButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
			}
		});
		this.add(ingredientsSearchSearchButton);
		
		JTextField ingredientsSearchSearchTextfield = new JTextField("suchen");
		ingredientsSearchSearchTextfield.setBounds(((int) (window.getWidth() * 0.54) + 60), 125, 340, 50);
		ingredientsSearchSearchTextfield.setFont(new Font(getFont().getFontName(), getFont().getStyle(), 20));
		this.add(ingredientsSearchSearchTextfield);
		
		String[] ingredientsNamesSearchContent = (String[]) content.get("Zutaten");
		SearchAndSelectField ingredients = new SearchAndSelectField((int)( window.getWidth() * 0.04), 125 + 50, 900, 200, ingredientsNamesSearchContent, this);
		this.add(ingredients);
		
		
		
		//bottom
		String[] categoriesNamesSearchContent = (String[]) content.get("Kategorien");
		SearchAndSelectField categories = new SearchAndSelectField((int)( window.getWidth() * 0.04), 125 + 350, 900, 200, categoriesNamesSearchContent, this);
		this.add(categories);
		
		JButton categoriesSearchSearchButton = new JButton("S");
		categoriesSearchSearchButton.setFont(new Font(getFont().getFontName(), getFont().getStyle(), 15));
		categoriesSearchSearchButton.setBackground(Color.WHITE);
		categoriesSearchSearchButton.setFocusable(false);
		categoriesSearchSearchButton.setBounds((int) ( window.getWidth() * 0.54), 125 + 300, 60, 50);
		categoriesSearchSearchButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
			}
		});
		this.add(categoriesSearchSearchButton);
		
		JTextField categoriesSearchSearchTextfield = new JTextField("suchen");
		categoriesSearchSearchTextfield.setBounds(((int) (window.getWidth() * 0.54) + 60), 125 + 300, 340, 50);
		categoriesSearchSearchTextfield.setFont(new Font(getFont().getFontName(), getFont().getStyle(), 20));
		this.add(categoriesSearchSearchTextfield);
		
		
		//pages
		JButton cancel = new JButton("Cancel");
		cancel.setBounds(100, 700, 300, 50);
		cancel.setFocusable(false);
		cancel.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				window.dispose();
				System.out.println(window.getComponentCount());
				
			}
		});
		this.add(cancel);
		
		
		JButton nextPage = new JButton("N�chste Seite");
		nextPage.setBounds(600, 700, 300, 50);
		nextPage.setFocusable(false);
		nextPage.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				setVisible(false);
				window.secondPage.setVisible(true);
				
			}
		});
		this.add(nextPage);
		
	}
	
	
}

