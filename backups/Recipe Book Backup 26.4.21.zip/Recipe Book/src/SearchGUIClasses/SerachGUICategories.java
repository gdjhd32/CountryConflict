package SearchGUIClasses;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class SerachGUICategories extends JPanel {
	SearchGUI window;
	
	public SerachGUICategories(SearchGUI window) {
		this.window = window;
		
		start();
	}

	
	private void start() {
		this.setBounds(window.getBounds());
		this.setVisible(true);
		this.setLayout(null);
		window.add(this);
		
		JButton recipesRecipes = new JButton("recipes");
		recipesRecipes.setBounds(0, 0, this.getWidth() / 3, 50);
		recipesRecipes.setFocusable(false);
		recipesRecipes.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				setVisible(false);
				window.recipes.setVisible(true);
			}
		});
		this.add(recipesRecipes);
		
		JButton recipesCategories = new JButton("categories");
		recipesCategories.setBounds(this.getWidth() / 3, 0, this.getWidth() / 3, 50);
		recipesCategories.setFocusable(false);
		recipesCategories.setBackground(Color.GREEN);
		this.add(recipesCategories);
		
		JButton recipesIngredients = new JButton("ingredients");
		recipesIngredients.setBounds( 2 * this.getWidth() / 3, 0, this.getWidth() / 3, 50);
		recipesIngredients.setFocusable(false);
		recipesIngredients.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				setVisible(false);
				window.ingredients.setVisible(true);
				
			}
		});
		this.add(recipesIngredients);
	}
}
