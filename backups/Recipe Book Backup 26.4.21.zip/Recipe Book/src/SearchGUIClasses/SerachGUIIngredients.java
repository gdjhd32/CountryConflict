package SearchGUIClasses;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class SerachGUIIngredients extends JPanel {

	SearchGUI window;

	public SerachGUIIngredients(SearchGUI window) {
		this.window = window;
		
		start();
	}


	private void start() {
		this.setBounds(window.getBounds());
		this.setVisible(true);
		this.setLayout(null);
		window.add(this);

		JButton recipes = new JButton("recipes");
		recipes.setBounds(0, 0, this.getWidth() / 3, 50);
		recipes.setFocusable(false);
		recipes.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				setVisible(false);
				window.recipes.setVisible(true);
			}
		});
		this.add(recipes);

		JButton categories = new JButton("categories");
		categories.setBounds(this.getWidth() / 3, 0, this.getWidth() / 3, 50);
		categories.setFocusable(false);
		categories.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				setVisible(false);
				window.categories.setVisible(true);

			}
		});
		this.add(categories);

		JButton ingredientsIngredients = new JButton("ingredients");
		ingredientsIngredients.setBounds(2 * this.getWidth() / 3, 0, this.getWidth() / 3, 50);
		ingredientsIngredients.setFocusable(false);
		ingredientsIngredients.setBackground(Color.GREEN);
		this.add(ingredientsIngredients);
	}
}