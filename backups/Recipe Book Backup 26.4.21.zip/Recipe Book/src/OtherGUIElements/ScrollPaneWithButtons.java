package OtherGUIElements;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.ArrayList;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;

@SuppressWarnings("serial")
public class ScrollPaneWithButtons extends JScrollPane {
	
	int x, y, width, height;
	
	JPanel panel;
	
	int verticalScrollBarValue;
	
	public ScrollPaneWithButtons(int x, int y, int width, int height, ArrayList<ArrayList<Component>> elementList) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		
		start();
		setNewContent(elementList);
		
	}
	
	private void start() {
		this.setBounds(x, y, width, height);
		this.getVerticalScrollBar().setUnitIncrement(2);
		this.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		this.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		
		panel = new JPanel();
		this.setViewportView(panel);
	}
	
	public void setNewContent(ArrayList<ArrayList<Component>> elementList) {
		
		panel.removeAll();
		
		GridBagLayout layout = new GridBagLayout();
		panel.setLayout(layout);
		GridBagConstraints constraints = new GridBagConstraints();
		constraints.insets = new Insets(0, 0, 0, 0);	
		
		for(int i = 0; i < elementList.size(); i++) {
			if(elementList.get(i) != null) { 
				
				JPanel everyLine = new JPanel();
				FlowLayout noGaps = new FlowLayout();
				noGaps.setHgap(0);
				noGaps.setVgap(0);
				everyLine.setLayout(noGaps);
				
				for(int o = 0; o < elementList.get(i).size(); o++) {
					
					Component objects = elementList.get(i).get(o);
					
					//constraints.ipadx = (int) objects[0];
					//constraints.ipady = (int) objects[1];
					constraints.ipadx = 1;
					constraints.ipady = 1;
					
					//constraints.gridx = o;
					constraints.gridx = 0;
					constraints.gridy = i;
					constraints.gridwidth = 1;
					constraints.gridheight = 1;
					
					
					Component component = objects;
					
					component.setName(Integer.toString(i)); //?
					
					//layout.setConstraints(component, constraints);
					
					//panel.add(component);
					
					everyLine.add(component);
				}
				layout.setConstraints(everyLine, constraints);
				panel.add(everyLine);
			}
		}
		this.updateUI();
		
	}
}
