package OtherGUIElements;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

@SuppressWarnings("serial")
public class SearchAndSelectField extends JPanel {
	
	ArrayList<ArrayList<Component>> searchContentComplete;
	ArrayList<ArrayList<Component>> searchContent;
	ArrayList<ArrayList<Component>> selectedContent;
	
	ArrayList<Component> searchFields;
	
	String[] namesSearchContent;
	
	ArrayList<String> selcetedTxtes;
	
	ScrollPaneWithButtons searchScrollPane;
	ScrollPaneWithButtons selectedScrollPane;
	
	JPanel highestJPanel;
	
	public SearchAndSelectField(int x, int y, int width, int height, String[] namesSearchContent, JPanel highestJPanel) {
		this.setBounds(x, y, width, height);
		this.namesSearchContent = namesSearchContent;
		this.highestJPanel = highestJPanel;

		
		start();
	}
	
	public ScrollPaneWithButtons getScrollPaneWithButtons() {
		return searchScrollPane;
	}
	
	private void start() {
		
		selcetedTxtes = new ArrayList<>();
		
		selectedContent = new ArrayList<>();
		searchContent = new ArrayList<>();		
		
		
		//right
		
		for(int i = 0; i < namesSearchContent.length; i++) {
			addSearch(namesSearchContent[i]);
		}
		
		this.searchScrollPane = new ScrollPaneWithButtons(this.getX() + 500, this.getY(), 400, this.getHeight(), searchContent);
		highestJPanel.add(searchScrollPane);
			
		
		//left 
		
		selectedScrollPane = new ScrollPaneWithButtons(this.getX(), this.getY() - 50, 400, this.getHeight() + 50, selectedContent);
		highestJPanel.add(selectedScrollPane);
		

		
		
	}
	
	private void reload() {
		
		searchScrollPane.setNewContent(searchContent);
		
		selectedScrollPane.setNewContent(selectedContent);
	}
	
	private void addSelected(String text) {
		
		selcetedTxtes.add(text);
		
		JTextField textFieldOne = new JTextField("0");
		textFieldOne.setHorizontalAlignment((int) CENTER_ALIGNMENT);
		textFieldOne.addKeyListener(new KeyAdapter() {
			
	         public void keyReleased(KeyEvent ke) {
	        	 if (ke.getKeyChar() <= '0' || ke.getKeyChar() >= '9') {	//checks if text in textFieldOne is valid, triggers also with comma, because it could be two commas
	        		 textFieldOne.setText(correctNumberfield(textFieldOne.getText().toCharArray())); 	//makes text in textFieldOne valid
	        	 }
	         }
	      });
		textFieldOne.setEditable(true);
		textFieldOne.setPreferredSize(new Dimension(60, 50));
		
		
		JTextField textFieldTwo = new JTextField(text);
		textFieldTwo.setFont(new Font(getFont().getFontName(), getFont().getStyle(), 15));
		textFieldTwo.setPreferredSize(new Dimension(244, 50));
		textFieldTwo.setVisible(true);
		textFieldTwo.setFocusable(false);
		textFieldTwo.setEditable(false);
		
		
		JButton buttonThree = new JButton("Back");
		buttonThree.setPreferredSize(new Dimension(75, 50));
		buttonThree.setName(Integer.toString(selectedContent.size() + 1));
		buttonThree.setFocusable(false);
		buttonThree.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				//addSearch(textFieldTwo.getText());
				//setSearchUnselected(textFieldTwo.getText());
				selectedContent.remove(Integer.parseInt(buttonThree.getName()));
				
				for(int i = 0; i < searchContent.size(); i++) {
					if(searchContent.get(i).size() == 2) {
						if(((JButton) searchContent.get(i).get(1)).getText().equalsIgnoreCase(textFieldTwo.getText())) {
							
							searchContent.get(i).remove(0);
							
							((JButton) searchContent.get(i).get(0)).setPreferredSize(new Dimension(380, 50));
							
							reload();
							break;
						}
					}
				}
				
				
				selcetedTxtes.remove(text);
				
			}
		});
		
		ArrayList<Component> listAtI = new ArrayList<>();
		listAtI.add(textFieldOne);
		listAtI.add(textFieldTwo);
		listAtI.add(buttonThree);
		selectedContent.add(listAtI);
	
	}
	
	private void setSearchSelected(int index) {
		//make that the search object has the icon
		
		
		JLabel labelOne = new JLabel();
		labelOne.setBackground(Color.WHITE);
		labelOne.setSize(new Dimension(55, 50));
		
		ImageIcon icon = new ImageIcon("C:\\Users\\wilga\\eclipse-workspace\\Recipe Book\\bin\\visuals\\haken.png");
		Image image = icon.getImage();
		Image imageScaled = image.getScaledInstance(labelOne.getWidth(), labelOne.getHeight(), Image.SCALE_SMOOTH);
		ImageIcon iconScaled = new ImageIcon(imageScaled);
		labelOne.setIcon(iconScaled); //------------------------------------> without icon, white icon
				
		
		searchContent.get(index).add(0, labelOne);
		
		reload();
	}
	
	private void addSearch(String text) {
		
		//right
		
		JButton buttonTwo = new JButton(text); 		
		buttonTwo.setPreferredSize(new Dimension(380, 50));
		buttonTwo.setName(Integer.toString(searchContent.size() + 1));
		buttonTwo.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				if(searchContent.get(Integer.parseInt(buttonTwo.getName())).size() == 1) {
					buttonTwo.setPreferredSize(new Dimension(325, 50));
					addSelected(buttonTwo.getText());
					setSearchSelected(Integer.parseInt(buttonTwo.getName()));
				}
				
			}
		});
		buttonTwo.setFocusable(false);		
		
		ArrayList<Component> listAtI = new ArrayList<>();
		listAtI.add(buttonTwo);
		searchContent.add(listAtI);
		
	}
	
	//getSelected
	
	//search -------------> select all of String[] that fit all search names from all search fields
	
	//addSearchField(JButton searchButton, JTextField searchTextField)
	//search.addActionListener(new ActionListener{search()})
	//Object[] objects = new Object[2]
	//objects[0] = searchButton
	//objects[1] = searchTextField
	
	private String correctNumberfield(char[] carArray) {
		ArrayList<Character> list = new ArrayList<Character>();
		boolean nextCommaValid = true;
    	for(int i = 0; i < carArray.length; i++) {
    		if (carArray[i] >= '0' && carArray[i] <= '9' || carArray[i] == ',' && nextCommaValid) {
    			list.add(carArray[i]);
    			if(carArray[i] == ',') {
    				nextCommaValid = false;
    			}
    		}
    	}
    	String newContent = new String();
    	for(int i = 0; i < list.size(); i++) {
    		newContent = newContent + Character.toString((char) list.toArray()[i]);
    	}
    	return newContent;
	}
}
